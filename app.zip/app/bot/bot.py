from botbuilder.core import TurnContext, CardFactory, MessageFactory
from botbuilder.schema import ActivityTypes

from app.cards.approval_card import get_approval_card
from app.cards.result_card import get_result_card
from app.services.defender import block_ip


class TeamsBot:

    async def on_turn(self, turn_context: TurnContext):
        activity = turn_context.activity

        if activity.type == ActivityTypes.message:
            await self._handle_message(turn_context)

        elif activity.type == "invoke":
            await self._handle_invoke(turn_context)

    # ── Incoming text messages ─────────────────────────────────────
    async def _handle_message(self, turn_context: TurnContext):
        text = (turn_context.activity.text or "").strip().lower()

        if "help" in text or not text:
            await turn_context.send_activity(
                "👋 I monitor for suspicious IPs.\n\n"
                "When one is detected I'll send an approval card here.\n"
                "You can also type: **block ip <address>** to manually trigger a review."
            )
            return

        # Manual trigger: "block ip 1.2.3.4"
        if text.startswith("block ip"):
            parts = text.split()
            ip = parts[2] if len(parts) >= 3 else None
            if not ip:
                await turn_context.send_activity("Please include an IP: `block ip 1.2.3.4`")
                return
            await self._send_approval_card(turn_context, ip, "Manually triggered")
            return

        await turn_context.send_activity("Type **help** to see what I can do.")

    # ── Adaptive Card button clicks arrive here ────────────────────
    async def _handle_invoke(self, turn_context: TurnContext):
        value  = turn_context.activity.value or {}
        action = value.get("action")
        ip     = value.get("ip_address", "").strip()

        if action == "approve_block":
            await self._do_block(turn_context, ip)

        elif action == "reject_block":
            await self._do_reject(turn_context, ip)

    # ── Send the approval card to Teams ───────────────────────────
    async def _send_approval_card(
        self,
        turn_context: TurnContext,
        ip: str,
        reason: str = "Suspicious activity detected"
    ):
        card       = get_approval_card(ip, reason)
        attachment = CardFactory.adaptive_card(card)
        await turn_context.send_activity(MessageFactory.attachment(attachment))

    # ── Admin clicked Accept ───────────────────────────────────────
    async def _do_block(self, turn_context: TurnContext, ip: str):
        await turn_context.send_activity(f"⏳ Blocking `{ip}` in Microsoft Defender...")

        result = block_ip(ip)          # calls your existing defender.py

        detail = ""
        if result["success"]:
            detail = result.get("data", {}).get("id", "Indicator created")
        else:
            detail = str(result.get("error", "Unknown error"))

        card       = get_result_card(ip, result["success"], detail)
        attachment = CardFactory.adaptive_card(card)
        await turn_context.send_activity(MessageFactory.attachment(attachment))

    # ── Admin clicked Reject ───────────────────────────────────────
    async def _do_reject(self, turn_context: TurnContext, ip: str):
        card       = get_result_card(ip, success=False, rejected=True,
                                     detail="Admin chose not to block this IP")
        attachment = CardFactory.adaptive_card(card)
        await turn_context.send_activity(MessageFactory.attachment(attachment))