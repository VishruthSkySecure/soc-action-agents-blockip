from botbuilder.core import BotFrameworkAdapter, BotFrameworkAdapterSettings
from botbuilder.schema import Activity
from app.core.config import settings
import traceback

adapter_settings = BotFrameworkAdapterSettings(
    app_id=settings.APP_ID,
    app_password=settings.APP_PASSWORD,
)

adapter = BotFrameworkAdapter(adapter_settings)

# This catches ALL errors and prints the real reason
async def on_error(context, error):
    print("=" * 60)
    print("BOT ERROR CAUGHT:")
    print(str(error))
    print(traceback.format_exc())
    print("=" * 60)
    await context.send_activity("Bot hit an error. Check terminal.")

adapter.on_turn_error = on_error