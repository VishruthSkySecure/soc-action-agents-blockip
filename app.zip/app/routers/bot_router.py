from fastapi import APIRouter, Request, Response
from botbuilder.schema import Activity
from botbuilder.core import CardFactory, MessageFactory, TurnContext

from app.bot.adapter import adapter
from app.bot.bot import TeamsBot
from app.cards.approval_card import get_approval_card
from app.core.config import settings

router = APIRouter()
bot = TeamsBot()

# Store conversation reference when bot first gets a message
conversation_reference = None


@router.post("/api/messages")
async def messages(req: Request):
    global conversation_reference

    if "application/json" not in req.headers.get("Content-Type", ""):
        return Response(status_code=415)

    body        = await req.json()
    activity    = Activity().deserialize(body)
    auth_header = req.headers.get("Authorization", "")

    # Save conversation reference the first time we get any message
    if conversation_reference is None:
        from botbuilder.core import BotFrameworkAdapter
        conversation_reference = TurnContext.get_conversation_reference(activity)

    invoke_response = await adapter.process_activity(
        activity,
        auth_header,
        bot.on_turn,
    )

    if invoke_response:
        return Response(
            content=str(invoke_response.body),
            status_code=invoke_response.status,
            media_type="application/json",
        )

    return Response(status_code=201)


# ── TEST ENDPOINT — hit this to trigger the approval card ──────────
@router.get("/test/block")
async def test_block():
    global conversation_reference

    if conversation_reference is None:
        return {"error": "No conversation yet. Message the bot in Teams first."}

    HARDCODED_IP = "0.0.0.0"
    HARDCODED_REASON = "Suspicious port scan detected (test)"

    card       = get_approval_card(HARDCODED_IP, HARDCODED_REASON)
    attachment = CardFactory.adaptive_card(card)
    message    = MessageFactory.attachment(attachment)

    async def send_card(tc: TurnContext, __):
        await tc.send_activity(message)

    await adapter.continue_conversation(
        conversation_reference,
        send_card,
        app_id=settings.APP_ID,
    )

    return {"status": "Approval card sent to Teams", "ip": HARDCODED_IP}