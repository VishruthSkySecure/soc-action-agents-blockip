from fastapi import FastAPI
from app.routers.bot_router import router

app = FastAPI(title="Teams Defender Bot")
app.include_router(router)

@app.get("/health")
def health():
    return {"status": "ok"}