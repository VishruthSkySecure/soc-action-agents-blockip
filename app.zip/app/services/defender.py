import requests
from app.core.config import settings

def get_token() -> str | None:
    url = f"https://login.microsoftonline.com/{settings.DEFENDER_TENANT_ID}/oauth2/v2.0/token"
    payload = {
        "client_id":     settings.DEFENDER_CLIENT_ID,
        "client_secret": settings.DEFENDER_CLIENT_SECRET,
        "scope":         "https://api.securitycenter.microsoft.com/.default",
        "grant_type":    "client_credentials",
    }
    r = requests.post(url, data=payload)
    if r.status_code == 200:
        return r.json()["access_token"]
    return None

def block_ip(ip_address: str) -> dict:
    """Block an IP via Defender. Returns result dict."""
    token = get_token()
    if not token:
        return {"success": False, "error": "Could not obtain token"}

    url = "https://api.security.microsoft.com/api/indicators"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type":  "application/json",
    }
    payload = {
        "indicatorValue": ip_address,
        "indicatorType":  "IpAddress",
        "action":         "Block",
        "title":          f"Blocked via Teams Bot",
        "description":    f"IP {ip_address} blocked via Teams automation",
        "severity":       "High",
    }
    r = requests.post(url, headers=headers, json=payload)
    if r.status_code in (200, 201):
        return {"success": True, "data": r.json()}
    return {"success": False, "error": r.json()}